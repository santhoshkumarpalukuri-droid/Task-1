document.addEventListener("DOMContentLoaded", function() {
  fetch('partials/header.html')
    .then(response => response.text())
    .then(data => {
      document.getElementById('header').innerHTML = data;
  
      const hamburger = document.querySelector('.hamburger');
      const navLinks = document.querySelector('.nav-links');
      if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
          navLinks.classList.toggle('active');
          hamburger.classList.toggle('active');
        });
      }
    })
    .catch(error => {
      console.error('Error loading header:', error);
 
      document.getElementById('header').innerHTML = '<header class="site-header"><nav class="nav container"><h1 class="logo">Mudamanchu Services</h1><ul class="nav-links"><li><a href="index.html">Home</a></li><li><a href="about.html">About</a></li><li><a href="services.html">Services</a></li><li><a href="contact.html">Contact</a></li></ul></nav></header>';
    });

  fetch('partials/footer.html')
    .then(response => response.text())
    .then(data => {
      document.getElementById('footer').innerHTML = data;
    })
    .catch(error => {
      console.error('Error loading footer:', error);
    
      document.getElementById('footer').innerHTML = '<footer class="site-footer"><p>Copyrights to Mudamanchu Services</p></footer>';
    });
});
