# TODO List for Authentication Flow Implementation

- [x] Update server.js: Add /header route to serve dynamic header based on authentication status.
- [x] Update js/include.js: Change fetch to '/header' instead of '/partials/header.html'.
- [x] Update server.js: Change logout redirect to '/login'.
- [x] Test the application: Run npm start, verify flow: start -> login page, login -> home, access all pages, logout -> login.
