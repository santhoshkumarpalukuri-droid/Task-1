document.addEventListener("DOMContentLoaded", function() {
  console.log('Loading header...');
  fetch('/header')
    .then(response => {
      console.log('Header fetch response:', response.status);
      return response.text();
    })
    .then(data => {
      console.log('Header loaded successfully');
      document.getElementById('header').innerHTML = data;
      // Add hamburger menu toggle after header is loaded
      const hamburger = document.querySelector('.hamburger');
      const navLinks = document.querySelector('.nav-links');
      if (hamburger && navLinks) {
        hamburger.addEventListener('click', () => {
          navLinks.classList.toggle('active');
          hamburger.classList.toggle('active');
        });
      }
    })
    .catch(error => {
      console.error('Error loading header:', error);
      // Fallback: insert basic header
      document.getElementById('header').innerHTML = '<header class="site-header"><nav class="nav container"><h1 class="logo">Mudamanchu Services</h1><ul class="nav-links"><li><a href="/">Home</a></li><li><a href="/about">About</a></li><li><a href="/services">Services</a></li><li><a href="/contact">Contact</a></li><li><a href="/login">Login</a></li><li><a href="/signup">Sign Up</a></li></ul></nav></header>';
    });

  fetch('/partials/footer.html')
    .then(response => response.text())
    .then(data => {
      document.getElementById('footer').innerHTML = data;
    })
    .catch(error => {
      console.error('Error loading footer:', error);
      // Fallback: insert basic footer
      document.getElementById('footer').innerHTML = '<footer class="site-footer"><p>Copyrights to Mudamanchu Services</p></footer>';
    });
});
