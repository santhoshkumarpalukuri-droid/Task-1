const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');

const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/mudamanchu-services', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch(err => {
  console.error('MongoDB connection error:', err);
});

// User schema
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String
});

const User = mongoose.model('User', userSchema);

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'mudamanchu-secret-key',
  resave: false,
  saveUninitialized: true
}));

// Middleware to protect HTML files except login and signup and partials
app.use((req, res, next) => {
  if (req.path.endsWith('.html') && req.path !== '/login.html' && req.path !== '/signup.html' && !req.path.startsWith('/partials/')) {
    requireAuth(req, res, next);
  } else {
    next();
  }
});

// Serve static files
app.use(express.static(path.join(__dirname)));

// Middleware to check authentication
function requireAuth(req, res, next) {
  if (req.session.user) {
    return next();
  } else {
    res.redirect('/login');
  }
}

// Routes
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.send('Please provide email and password. <a href="/login">Try again</a>');
  }
  try {
    // Find user and verify password
    const user = await User.findOne({ email });
    if (!user || user.password !== password) {
      return res.send('Invalid credentials. <a href="/login">Try again</a>');
    }
    req.session.user = email;
    res.redirect('/');
  } catch (err) {
    console.error(err);
    res.send('An error occurred. <a href="/login">Try again</a>');
  }
});

app.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, 'signup.html'));
});

app.post('/signup', async (req, res) => {
  const { name, email, password } = req.body;
  console.log('Signup attempt:', name, email);
  if (!name || !email || !password) {
    console.log('Missing fields');
    return res.send('Please provide name, email, and password. <a href="/signup">Try again</a>');
  }
  try {
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    console.log('Existing user check:', existingUser);
    if (existingUser) {
      console.log('User already exists');
      return res.send('Email already registered. <a href="/login">Login instead</a> or <a href="/signup">Try again</a>');
    }
    // Create new user
    const newUser = new User({ name, email, password });
    await newUser.save();
    console.log('User saved successfully');
    req.session.user = email;
    res.redirect('/');
  } catch (err) {
    console.error('Signup error:', err);
    res.send('An error occurred. <a href="/signup">Try again</a>');
  }
});

app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.send('Error logging out');
    }
    res.redirect('/login');
  });
});

app.get('/header', (req, res) => {
  let navLinks;
  if (req.session.user) {
    navLinks = `
      <li><a href="/">Home</a></li>
      <li><a href="/about">About</a></li>
      <li><a href="/services">Services</a></li>
      <li><a href="/contact">Contact</a></li>
      <li><a href="/logout">Logout</a></li>
    `;
  } else {
    navLinks = `
      <li><a href="/login">Login</a></li>
      <li><a href="/signup">Sign Up</a></li>
    `;
  }
  const headerHTML = `
<header class="site-header">
  <nav class="nav container">
    <h1 class="logo">Mudamanchu Services</h1>
    <button class="hamburger" aria-label="Toggle navigation">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </button>
    <ul class="nav-links">
      ${navLinks}
    </ul>
  </nav>
</header>
  `;
  res.send(headerHTML);
});

// Protected routes
app.get('/', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/about', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'about.html'));
});

app.get('/services', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'services.html'));
});

app.get('/contact', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'contact.html'));
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
